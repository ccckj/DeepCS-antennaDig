import os
import pdb
import math
import numpy as np 
import torch
import scipy.io as sio
from torch.utils import data
#sample_nums = 3e5
#antenna_size = 256
#fault_prob = 0.1
#SNR = 30

def matDataLoad(nums, size, prob, snr, measurements,normalization=False, outliersReduction = False, data1Dim=False):
    '''
    this function calculate the real part and the imag part of the complex data respectively
    '''
    dataPath = "../matlabAPI/data/datas_n{:.0f}_s{:.0f}_p{:.0f}_snr{:.0f}.mat".format(nums,size,prob*100,snr)
    labelPath = "../matlabAPI/data/labels_n{:.0f}_s{:.0f}_p{:.0f}_snr{:.0f}.mat".format(nums,size,prob*100,snr)
    #dataPath = '../matlabAPI/2e5_datas_s256_snr10000.mat'
    #labelPath = '../matlabAPI/2e5_labels_s256_snr10000.mat'
    load_data = sio.loadmat(dataPath)
    load_label = sio.loadmat(labelPath)
    comDatas = load_data['datas']
    comLabels = load_label['labels']
    assert measurements <= comDatas.shape[-1], \
        'expect maximum measurements is {e}, but got {r}'.format(e=comDatas.shape[-1], r=measurements)
    comDatas = comDatas[:, :measurements]
    if normalization:
        comDatas = dataNormlized(comDatas)
    b, s = comDatas.shape
    datas = np.zeros((b,2,s))
    labels = np.zeros((b,2,s))

    datas[:,0,:] = comDatas.real
    datas[:,1,:] = comDatas.imag
    labels[:,0,:] = comLabels.real
    labels[:,1,:] = comLabels.imag
    if data1Dim:
        return datas, labels
    assert datas.shape[-1] == size, 'data size inconsistent ^_^'
    xsize = int(np.sqrt(size))
    datas = np.reshape(datas, (b, 2, xsize,-1))
    labels = np.reshape(labels, (b, 2, xsize, -1))
    #pdb.set_trace()
    return datas, labels

def matDataLoadv2(nums, size, prob, snr, measurements, normalization=True):
    '''
    this function calculate the real part and the imag part of the complex data respectively
    '''
    dataPath = "../matlabAPI/data/datas_n{:.0f}_s{:.0f}_p{:.0f}_snr{:.0f}.mat".format(nums,size,prob*100,snr)
    labelPath = "../matlabAPI/data/labels_n{:.0f}_s{:.0f}_p{:.0f}_snr{:.0f}.mat".format(nums,size,prob*100,snr)
    #dataPath = '../matlabAPI/2e5_datas_s256_snr10000.mat'
    #labelPath = '../matlabAPI/2e5_labels_s256_snr10000.mat'
    load_data = sio.loadmat(dataPath)
    load_label = sio.loadmat(labelPath)
    comDatas = load_data['datas']
    comLabels = load_label['labels']
    assert measurements <= comDatas.shape[-1], \
        'expect maximum measurements is {e}, but got {r}'.format(e=comDatas.shape[-1], r=measurements)
    comDatas = comDatas[:, :measurements]
    if normalization:
        comDatas = dataNormlized(comDatas)
    return comDatas, comLabels


def matDataLoadv3(nums, size_x, size_y, prob, snr, measurements, normalization=False):
    '''
    this function load the data for LISTA + CNN。
    '''
    dataPath = "../matlabAPI/data/datas_n{:.0f}_s{:.0f}_p{:.0f}_snr{:.0f}.mat".format(nums,size_x*size_y,prob*100,snr)
    labelPath = "../matlabAPI/data/labels_n{:.0f}_s{:.0f}_p{:.0f}_snr{:.0f}.mat".format(nums,size_x*size_y,prob*100,snr)
    load_data = sio.loadmat(dataPath)
    load_label = sio.loadmat(labelPath)
    comDatas = load_data['datas']
    comLabels = load_label['labels']
    assert measurements <= comDatas.shape[-1], \
        'expect maximum measurements is {e}, but got {r}'.format(e=comDatas.shape[-1], r=measurements)
    comDatas = comDatas[:, :measurements]
    if normalization:
        comDatas = dataNormlized(comDatas)
    b, s = comDatas.shape
    datas = np.zeros((b, 2 * s))
    labels = np.zeros((b,2,size_x*size_y))

    datas[:,:s] = comDatas.real
    datas[:,s:] = comDatas.imag
    labels[:,0,:] = comLabels.real
    labels[:,1,:] = comLabels.imag

    labels = np.reshape(labels, (b, 2, size_x, -1))
    #pdb.set_trace()
    return datas, labels
    

def ArrayResposeLoad(measurements, antenna_x, antenna_y, com2real=True):
    thetaPath = "../matlabAPI/theta.mat"
    phiPath = "../matlabAPI/phi.mat"
    load_theta = sio.loadmat(thetaPath)
    load_phi = sio.loadmat(phiPath)
    theta = load_theta['theta'][0]
    phi = load_phi['phi'][0]
    antenna_size = antenna_x * antenna_y
    A_ = np.zeros((measurements, antenna_size)) + 1j*np.zeros((measurements, antenna_size))
    A = np.zeros((2*measurements, 2*antenna_size))
    m = np.arange(antenna_x)
    n = np.arange(antenna_y)
    for i in range(measurements):
        ax = np.exp(1j * m * np.pi * np.sin(theta[i]) * np.cos(phi[i]))
        ay = np.exp(1j * n * np.pi * np.sin(theta[i]) * np.sin(phi[i]))
        A_[i,:] = np.kron(ax,ay)
    if not com2real:
        return A_
    A[:measurements, :antenna_size] = np.real(A_)
    A[:measurements, antenna_size:] = -np.imag(A_)
    A[measurements:, :antenna_size] = np.imag(A_)
    A[measurements:, antenna_size:] = np.real(A_)
    return A


def dataNormlized(datas):
    dim = datas.shape[1]
    mean_feature = np.zeros(dim)+ 1j*np.zeros(dim)
    for i in range(dim):
        data = datas[:,i]
        data_r = np.real(data)
        data_i = np.imag(data)
        ptr = np.percentile(data_r, [2.5, 97.5])
        pti = np.percentile(data_i, [2.5, 97.5])
        idr = (data_r >= ptr[0]) & (data_r <= ptr[1])
        idi = (data_i >= pti[0]) & (data_i <= pti[1])
        vld_data_r = data_r[idr]
        vld_data_i = data_i[idi]
        mean_feature[i] = np.mean(vld_data_r) + 1j*np.mean(vld_data_i)
    norm_datas = datas - mean_feature
    return norm_datas
    

    

def dataSplit(datas, labels, ratio=0.8):
    assert datas.shape[0]==labels.shape[0], 'data and label inconsistent!'
    num_samples = datas.shape[0]
    idx = np.arange(num_samples)
    #np.random.shuffle(idx) can not be shuffled
    train_sample_num = math.ceil(num_samples * ratio)
    train_sample_id = idx[:train_sample_num]
    val_sample_id = idx[train_sample_num:]
    return train_sample_id, val_sample_id
    

class CnnDataLoader(data.Dataset):
    def __init__(self,  args, flag='train', dataNorm=False, data1Dim=False):
        '''
            flag: ['train' | 'val' | 'test']
        '''
        self.flag = flag
        datas, labels = matDataLoad(args.sample_nums, args.antenna_size, args.fault_prob, args.SNR,\
                        args.measurements, dataNorm, data1Dim=data1Dim)
        train_sample_id, val_sample_id = dataSplit(datas, labels, ratio=0.8)
        if self.flag == 'train':
            self.datas, self.labels = datas[train_sample_id], labels[train_sample_id]
        else:
            self.datas, self.labels = datas[val_sample_id], labels[val_sample_id]
        
    def __len__(self):
        return len(self.datas)
    def __getitem__(self, index):
        img = self.datas[index]
        gt = self.labels[index]
        img = torch.from_numpy(img).float()
        gt = torch.from_numpy(gt).float()
        if self.flag == 'test':
            return img
        # mask[i,j] = 1 where the position of (i,j) antenna is faulty
        gt[0] = 1 - gt[0] 
        mask = gt[0]
        mask = mask!=0
        mask = torch.unsqueeze(mask,0).float()
        return img, gt, mask

class ListaDataLoader(data.Dataset):
    def __init__(self, args, com2real=True, flag='train', dataNorm=False):
        '''
            flag: ['train' | 'val' | 'test']
        '''
        self.flag = flag
        self.com2real = com2real
        datas, labels = matDataLoadv2(args.sample_nums, args.antenna_x * args.antenna_y, args.fault_prob, args.SNR, args.measurements, dataNorm)
        train_sample_id, val_sample_id = dataSplit(datas, labels, ratio=0.8)
        if self.flag == 'train':
            self.datas, self.labels = datas[train_sample_id], labels[train_sample_id]
        else:
            self.datas, self.labels = datas[val_sample_id], labels[val_sample_id]
    def __len__(self):
        return len(self.datas)
    def __getitem__(self, index):
        y = self.datas[index]
        x = self.labels[index]
        x = 1 - x
        if self.com2real:
            M = y.shape[-1]
            N = x.shape[-1]
            y_ = np.zeros(2*M)
            x_ = np.zeros(2*N)
            y_[:M] = np.real(y)
            y_[M:] = np.imag(y)
            x_[:N] = np.real(x)
            x_[N:] = np.imag(x)
            x, y = x_, y_
        y = torch.from_numpy(y).float()
        x = torch.from_numpy(x).float()
        if self.flag == 'test':
            return y
        return y, x

class DenoiseDataLoader(data.Dataset):
    def __init__(self,  args, flag='train', dataNorm=False):
        '''
            flag: ['train' | 'val' | 'test']
        '''
        self.flag = flag
        datas, labels = matDataLoadv3(args.sample_nums, args.antenna_x, args.antenna_y, args.fault_prob, args.SNR,\
                        args.measurements, dataNorm)
        train_sample_id, val_sample_id = dataSplit(datas, labels, ratio=0.8)
        if self.flag == 'train':
            self.datas, self.labels = datas[train_sample_id], labels[train_sample_id]
        else:
            self.datas, self.labels = datas[val_sample_id], labels[val_sample_id]
        
    def __len__(self):
        return len(self.datas)
    def __getitem__(self, index):
        img = self.datas[index]
        gt = self.labels[index]
        img = torch.from_numpy(img).float()
        gt = torch.from_numpy(gt).float()
        if self.flag == 'test':
            return img
        # mask[i,j] = 1 where the position of (i,j) antenna is faulty
        gt[0] = 1 - gt[0] 
        mask = gt[0]
        mask = mask!=0
        mask = torch.unsqueeze(mask,0).float()
        return img, gt, mask

if __name__ == "__main__":
    #datas, labels = matDataProcessing()
    datas, labels = matDataLoadv3(3e5, 16, 16, 0.1, 30, 250)


    pdb.set_trace()

