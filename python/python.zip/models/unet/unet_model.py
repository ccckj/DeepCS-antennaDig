""" Full assembly of the parts to form the complete network """

import torch.nn.functional as F
from torch import nn
import numpy as np
from .unet_parts import *
import pdb

def shrink(input_, theta_):
    theta_ = torch.clamp(theta_, min=0.0)
    return torch.sign(input_) * torch.clamp(torch.abs(input_) - theta_, min=0.0)

class UNet(nn.Module):
    def __init__(self,n_channels=2, n_classes=1, bilinear=True, expansion=None):
        super(UNet, self).__init__()
        self.n_channels = n_channels
        self.n_classes = n_classes
        self.bilinear = bilinear
        self.expansion = expansion
        self.inc = DoubleConv(n_channels, 64)
        self.down1 = Down(64, 128)
        self.down2 = Down(128, 256)
        self.down2 = Down(128, 256)
        self.down3 = Down(256, 512)
        self.down4 = Down(512, 512)
        self.up1 = Up(1024, 256, bilinear)
        self.up2 = Up(512, 128, bilinear)
        self.up3 = Up(256, 64, bilinear)
        self.up4 = Up(128, 64, bilinear)
        self.outc = OutConv(64, n_classes)
        self.outr = OutConv(64,2)
        #print('print paramsters!!!!')
        for id, (n,m) in enumerate(self.named_modules()):
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in',nonlinearity='leaky_relu')
                if n == 'outc.conv':
                    pi = 0.05
                    b = - np.log(1-pi) / pi
                    nn.init.constant_(m.bias,b)
                else:
                    nn.init.zeros_(m.bias.data)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
        #pdb.set_trace()

    def forward(self, x):
        if self.expansion is not None:
            x = F.interpolate(x, scale_factor=self.expansion, mode='bilinear',align_corners=True)
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        if self.expansion is not None:
            x = F.max_pool2d(x, kernel_size=self.expansion, stride=self.expansion)
        cls_logit = self.outc(x)
        reg_logit = self.outr(x)
        return reg_logit, cls_logit

class ShrinkUnet(nn.Module):
    def __init__(self, args, A, n_channels=2, n_classes=1, bilinear=True):
        """
        :A      : Numpy ndarray. Dictionary/Sensing matrix.
        :T      : Integer. Number of layers (depth) of this LISTA model.
        :lam    : Float. The initial weight of l1 loss term in LASSO.
        :coord: Whether use independent vector thresholds.
        """
        super(ShrinkUnet, self).__init__()
        self._A = torch.Tensor(A)
        self._T = args.T
        self._lam = args.lam
        self._ax = args.antenna_x
        self._ay = args.antenna_y
        self._M, self._N = A.shape
        self._scale = 1.001 * torch.norm (self._A)**2
        self._theta = (self._lam / self._scale)
        if args.coord:
            self._theta = torch.ones (self._N, 1) * self._theta
        B = torch.transpose(self._A, 0, 1) / self._scale
        W = torch.eye(self._N) - B.mm(self._A)
        self.B = nn.Parameter(B)
        self.W = nn.Parameter(W)
        self.theta = nn.Parameter(self._theta)

        self.denoiser = UNet(n_channels, n_classes, bilinear, args.expansion)

    def forward(self, y_, x0_=None):
        batch_size = y_.shape[0]
        if x0_ is None:
            device = y_.device
            xh_ = torch.zeros(self._N, batch_size).to(device)
        else:
            xh_ = x0_
        By_ = torch.mm(self.B , y_.transpose(0,1))
        xh_ = shrink(torch.mm(self.W, xh_) + By_, self.theta)
        x = xh_.transpose(0,1)
        x = torch.reshape(x, (batch_size, 2, -1))
        x = torch.reshape(x, (batch_size, 2, self._ax, self._ay))
        out = self.denoiser(x)
        return out

