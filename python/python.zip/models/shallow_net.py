import torch
import torch.nn as nn
import torchvision.models as models
import math
import pdb
from torchsummary import summary
import collections
import torch.nn.functional as F

def conv3x3(in_planes, out_planes, stride=1, padding=1, dilation=1, dims=1):
    if dims==1:
        return nn.Conv1d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=padding, bias=False, dilation=dilation)
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=padding, bias=False, dilation=dilation)



class ShaNet(nn.Module):
    def __init__(self, name='resnet18', expansion=5):
        super(ShaNet, self).__init__()
        self.expansion = expansion
        model_list = collections.OrderedDict()
        if name=='resnet18':
            backbone = models.resnet18()
        else:
            raise RuntimeError
        for name, child in backbone.named_children():
            if name == 'conv1':
                model_list['conv1'] = nn.Conv2d(2,64,7,2,3)
            
            elif name != 'fc':
                model_list[name] = child
        
        backbone = nn.Sequential(model_list)
        model_list.clear()
        self.backbone = backbone
        self.fc1 = nn.Linear(512, 256)
        self.fc2 = nn.Linear(512,512)
    def forward(self, x):
        if self.expansion is not None:
            x = F.interpolate(x, scale_factor=self.expansion, mode='bilinear',align_corners=True)
        out = self.backbone(x)
        out = torch.flatten(out, start_dim=1)

        cls_logit = self.fc1(out)
        reg_logit = self.fc2(out)
        cls_logit = cls_logit.contiguous().view(-1,1,16,16)
        reg_logit = reg_logit.contiguous().view(-1,2,16,16)
        return reg_logit, cls_logit




        



    



