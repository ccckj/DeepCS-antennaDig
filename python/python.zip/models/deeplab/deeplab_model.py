import torch
import torch.nn as nn
import pdb
import torch.nn.functional as F
from models.deeplab.aspp import build_aspp
from models.deeplab.decoder import build_decoder
from models.deeplab.backbone import build_backbone

class DeepLab(nn.Module):
    def __init__(self, backbone='resnet', output_stride=16, num_classes=1, pretrained=False, expansion=None):
        super(DeepLab, self).__init__()
        if backbone == 'drn':
            output_stride = 8
        BatchNorm = nn.BatchNorm2d
        self.expansion = expansion
        self.backbone = build_backbone(backbone, output_stride, BatchNorm, pretrained)
        self.aspp = build_aspp(backbone, output_stride, BatchNorm)
        self.decoder = build_decoder(num_classes, backbone, BatchNorm)
        self.outc = nn.Conv2d(256, num_classes, kernel_size=1, stride=1)
        self.outr = nn.Conv2d(256, 2, kernel_size=1, stride=1)
        self._init_weight()
    def forward(self,input):
        _, _, w, h = input.size() 
        if self.expansion is not None:
            input = F.interpolate(input, scale_factor=self.expansion, mode='bilinear', align_corners=True)
        x, low_level_feat = self.backbone(input)
        x = self.aspp(x)
        x = self.decoder(x, low_level_feat)
        #x = F.interpolate(x, size=(w,h), mode='bilinear', align_corners=True)
        x = F.adaptive_max_pool2d(x, output_size=(w,h))
        reg_logit = self.outr(x)
        cls_logit = self.outc(x)
        
        return reg_logit, cls_logit

    def _init_weight(self):
        for n,m in self.named_modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in',nonlinearity='leaky_relu')
                if n == 'outc.conv':
                    pi = 0.05
                    b = - np.log(1-pi) / pi
                    nn.init.constant_(m.bias,b)
                elif m.bias is not None:
                    nn.init.zeros_(m.bias.data)

            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()