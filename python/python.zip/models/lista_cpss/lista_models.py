import os
import pdb
import math
import numpy as np 
import torch
from torch import nn

def shrink(input_, theta_):
    theta_ = torch.clamp(theta_, min=0.0)
    return torch.sign(input_) * torch.clamp(torch.abs(input_) - theta_, min=0.0)

class LISTA(nn.Module):
    def __init__(self, A, T, lam, untied=True, coord=True):
        """
        :A      : Numpy ndarray. Dictionary/Sensing matrix.
        :T      : Integer. Number of layers (depth) of this LISTA model.
        :lam    : Float. The initial weight of l1 loss term in LASSO.
        :untied : Boolean. Flag of whether weights are shared within layers.
        :coord: Whether use independent vector thresholds.
        """
        super(LISTA, self).__init__()
        self._A = torch.Tensor(A)
        self._T = T
        self._lam = lam
        self._M, self._N = A.shape
        self._scale = 1.001 * torch.norm (self._A)**2
        self._theta = (self._lam / self._scale)
        if coord:
            self._theta = torch.ones (self._N, 1) * self._theta

        self._untied = untied
        self._coord  = coord
        self._setup_layers()
        #self._init_weight()

    def _setup_layers(self):
        Bs_ = []
        Ws_ = []
        thetas_ = []
        B = torch.transpose(self._A, 0, 1) / self._scale
        W = torch.eye(self._N) - B.mm(self._A)

        if not self._untied:
            
            Wp = nn.Parameter(W)
            self.register_parameter('W', Wp)
            Ws_.append(Wp)
            Ws_ = Ws_ * self._T

            Bp = nn.Parameter(B)
            self.register_parameter('B', Bp)
            Bs_.append(Bp)
            Bs_ = Bs_ * self._T

        for t in range(self._T):
            thetap = nn.Parameter(self._theta)
            theta_name = 'theta_%d'%(t+1)
            self.register_parameter(theta_name, thetap)
            thetas_.append(thetap)

            if self._untied:
                Wp = nn.Parameter(W)
                W_name = 'W_%d'%(t+1)
                self.register_parameter(W_name, Wp)
                Ws_.append(Wp)
                Bp = nn.Parameter(B)
                B_name = 'B_%d'%(t+1)
                self.register_parameter(B_name, Bp)
                Bs_.append(Bp)
        # register parameters
        self.vars_in_layer = list(zip(Bs_, Ws_, thetas_))

    def _init_weight(self):
        for name, para in self.named_parameters():
             if not 'theta' in name:
                 nn.init.kaiming_normal_(para)

    def forward(self, y_, x0_=None):
        xhs_ = []
        if x0_ is None:
            device = y_.device
            batch_size = y_.shape[-1]
            xh_ = torch.zeros(self._N, batch_size).to(device)
        else:
            xh_ = x0_
        xhs_.append(xh_)
        for t in range(self._T):
            B_, W_, theta_ = self.vars_in_layer[t]
            By_ = torch.mm(B_, y_)
            xh_ = shrink(torch.mm(W_, xh_) + By_, theta_)
            xhs_.append(xh_)
        return xhs_







if __name__ == "__main__":
    A = np.random.random((250,500))
    model = LISTA(A, 10, 0.6)
    for n, p in model.named_parameters():
        print(n)
        print(p)
        pdb.set_trace()