import os, sys
import numpy as np 
import torch
import collections
import pdb
import argparse
import models
from dataset import DenoiseDataLoader, CnnDataLoader, ArrayResposeLoad
from util.metric import nmse_metric_np as nmse_metric, runningScore
from util import AverageMeter

def update_score(preds, masks, running_metric, th=0.5):
    preds = torch.sigmoid(preds).data.cpu().numpy()
    preds[preds>=th] = 1
    preds[preds<th] = 0
    preds = preds.astype(np.int32)
    masks = masks.data.cpu().numpy().astype(np.int32)
    running_metric.update(masks, preds)
    #print("total sample:%d"%np.sum(running_metric.confusion_matrix))




def validate(args):
    avgNmse = AverageMeter()
    running_metric = runningScore(2)

    data_loader = DenoiseDataLoader(args, flag=args.flag)
    val_loader = torch.utils.data.DataLoader(
        data_loader,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4,
        drop_last=True
    )
    if args.arch == "unet":
        model = models.UNet(n_channels=2, n_classes=1, expansion=args.expansion)
    elif args.arch == "shrink-unet":
        A = ArrayResposeLoad(measurements=args.measurements, antenna_x=args.antenna_x, antenna_y=args.antenna_y)
        model = models.ShrinkUnet(args, A=A, n_channels=2, n_classes=1)
    for param in model.parameters():
        param.requires_grad = False
    device = args.device
    model = model.to(device)
    
    if args.resume is not None:
        if os.path.isfile(args.resume):
            print("Loading model from checkpoint '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            d = collections.OrderedDict()
            for key, value in checkpoint['state_dict'].items():
                tmp = key[7:]
                d[tmp] = value
            model.load_state_dict(d)
            print("Loaded checkpoint '{}' (epoch {})".format(args.resume, checkpoint['epoch']))
        else:
            tips = "No checkpoint found at '{}'".format(args.resume)
            raise RuntimeError(tips)
        sys.stdout.flush()
    model.eval()
    print('start to validate...')
    for idx, (imgs, gts, masks) in enumerate(val_loader):
        print('progress: %d / %d'%(idx+1, len(val_loader)))
        imgs = imgs.to(device)
        gts = gts.to(device)
        masks = masks.to(device)
        outputs = model(imgs)
        
        update_score(outputs[1], masks, running_metric, args.binary_th)
        nmse = nmse_metric(outputs[0], outputs[1], gts, args.binary_th)
        avgNmse.update(nmse, imgs.size(0))
    print('F1 score:', avgNmse.avg)
    print('normalized MSE:', running_metric.get_scores())





if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--flag', type=str, default='val', help="select 'train' | 'val' | 'test'")
    parser.add_argument('--device', type=str, default='cuda', help="select device to run the model")
    parser.add_argument('--expansion', type=int, default=5, help='expand the input data size')
    parser.add_argument('--arch',type=str, nargs='?', default='shrink-unet')
    parser.add_argument('--batch_size', type=int, nargs='?', default=500)
    parser.add_argument('--resume', type=str, default=None, help='Path to previous saved model to restart from')
    parser.add_argument('--binary_th', type=float, default=0.5, help='binary classification threshold')
    parser.add_argument('--fault_prob', type=float, help='probability of antenna faulty, it rely on the generated mat')
    parser.add_argument('--SNR', type=int, help="SNR of data")
    parser.add_argument('--sample_nums', type=int, default=3e5, help='total training and validate dataset size')
    parser.add_argument('--antenna_x', type=int, nargs='?', default=16)
    parser.add_argument('--antenna_y', type=int, nargs='?', default=16)
    parser.add_argument('--measurements', type=int, nargs='?', default=256)
    parser.add_argument('--T', type=int, nargs='?', default=1, help='Number of layers')
    parser.add_argument('--lam', type=float, nargs='?', default=0.4)
    parser.add_argument('--untied', type=bool, nargs='?', default=True, help="Flag of whether weights are shared within layers.")
    parser.add_argument('--coord', type=bool, nargs='?', default=True, help="Whether use independent vector thresholds")
    args = parser.parse_args()

    validate(args)