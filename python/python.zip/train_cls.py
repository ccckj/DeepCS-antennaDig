import sys, os
import pdb
import numpy as np 
import torch
import argparse
import models
import time
from util.metric import runningScore, nmse_metric_np as nmse_metric
from util import AverageMeter, Logger, nmse_loss, mse_loss, bce_loss, dice_loss, focal_loss_v2,focal_loss
from dataset import DataLoader
import torch.nn.functional as F
from util.adamw import AdamW


def adjust_learning_rate(args, optimizer, epoch):
    global state
    if epoch in args.schedule:
        args.lr = args.lr * 0.1
        for param_group in optimizer.param_groups:
            param_group['lr'] = args.lr

def save_checkpoint(state, epoch, checkpoint='checkpoint', filename='checkpoint.pth.rar'):
    filename = str(epoch) + '__' + filename
    filepath = os.path.join(checkpoint, filename)
    torch.save(state, filepath)

def save_best_checkpoint(state, checkpoint='checkpoint', filename='bestCheckpoint.pth.rar'):
    filepath = os.path.join(checkpoint, filename)
    torch.save(state, filepath)

def update_score(preds, masks, running_metric):
    preds = torch.sigmoid(preds).data.cpu().numpy()
    preds[preds>=0.5] = 1
    preds[preds<0.5] = 0
    preds = preds.astype(np.int32)
    masks = masks.data.cpu().numpy().astype(np.int32)
    running_metric.update(masks, preds)

def train(train_loader, model, optimizer, epoch):
    batch_time = AverageMeter()
    
    losses = AverageMeter()
    running_metric = runningScore(2)
    model.train()
    for batch_idx, (imgs, _, masks) in enumerate(train_loader):
        end = time.time()
        imgs = imgs.cuda()

        masks = masks.cuda()
        _, cls_outputs = model(imgs) #todo channge to dice loss
        # two kind losses
        loss_d = dice_loss(cls_outputs, masks)
        #loss_f = focal_loss_v2(cls_outputs, masks, alpha=0.5, size_average=True)
        loss = 10*loss_d 
        losses.update(loss.item(), imgs.size(0))

        optimizer.zero_grad()

        loss.backward()
        optimizer.step()
        update_score(cls_outputs, masks, running_metric)
        scores = running_metric.get_scores()
        batch_time.update(time.time() - end)
        if batch_idx % 10 == 0:
            output_log = '({batch}/{size} Batch: {bt:.3f}s | TOTAL: {total:.3f}min | ETA: {eta:.3f}min |  Loss: {loss:.6f} | Recall:{recall:.6f} | Precision:{precision:.6f} | F1:{f1_score:.6f})'.format(
                batch = batch_idx + 1,
                size = len(train_loader),
                bt = batch_time.avg,
                total = batch_time.avg * (len(train_loader)) / 60.0,
                eta = batch_time.avg * (len(train_loader) - batch_idx) /60.0,
                loss=losses.avg,
                recall=scores['recall'],
                precision = scores['precision'],
                f1_score=scores['f1_score']
                )
            print(output_log)
            sys.stdout.flush()
    return losses.avg, running_metric.get_scores()


def validate(model, args):
    data_loader = DataLoader(flag='val')
    val_loader = torch.utils.data.DataLoader(
        data_loader,
        batch_size=50,
        shuffle=False,
        num_workers=0,
        drop_last=True
    )

    running_metric = runningScore(2)

    #todo define F1score
    model.eval()
    for idx, (imgs, _, masks) in enumerate(val_loader):
        imgs = imgs.cuda()
        masks = masks.cuda()
        _, outputs = model(imgs)
        update_score(outputs, masks, running_metric)
    return running_metric.get_scores()


def main(args):
    start_epoch = 0
    if args.checkpoint=='':
        args.checkpoint = "checkpoint/%s_bs_%d_ep_%d_cls_only"%(args.arch, args.batch_size, args.n_epoch)
    print('checkpoint path: %s'%args.checkpoint)
    print('init lr: %.8f'%args.lr)
    #print('schedule: ', args.schedule)

    sys.stdout.flush()

    if not os.path.isdir(args.checkpoint):
        os.makedirs(args.checkpoint)
    data_loader = DataLoader()
    train_loader = torch.utils.data.DataLoader(
        data_loader,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=3,
        drop_last=True,
        pin_memory=True
    )
    if args.arch == "unet":
        model = models.UNet(n_channels=2, n_classes=1, expansion=args.expansion)
    elif args.arch == "deeplab-resnet":
        model = models.DeepLab(backbone='resnet', num_classes=1, expansion=args.expansion)
    elif args.arch == "deeplab-drn":
        model = models.DeepLab(backbone='drn', num_classes=1, expansion=args.expansion)
    elif args.arch == 'deeplab-mobilenet':
        model = models.DeepLab(backbone='mobilenet', num_classes=1, expansion=args.expansion)
    model = torch.nn.DataParallel(model).cuda()
    if hasattr(model.module, 'optimizer'):
        optimizer = model.module.optimizer
    else:
        #optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=5e-4)
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
        #optimizer = AdamW(model.parameters(), lr=args.lr)
    #pdb.set_trace()
    if args.pretrain:
        print('Using pretrained model.')
        assert os.path.isfile(args.pretrain), 'Error: no checkpoint directory found!'
        checkpoint = torch.load(args.pretrain)
        model.load_state_dict(checkpoint['state_dict'])
        logger = Logger(os.path.join(args.checkpoint, 'log.txt'))
        logger.set_names(['Epoch', 'Learning Rate','Train Loss', 'recall', 'precision','f1'])
    elif args.resume:
        print("Resuming from checkpoint")
        assert os.path.isfile(args.resume), 'Error: no resume checkpoint directory found!'
        checkpoint = torch.load(args.resume)
        start_epoch = checkpoint['epoch']
        model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        logger = Logger(os.path.join(args.checkpoint, 'log.txt'), resume=True)
    else:
        print('Training from scratch.')
        logger = Logger(os.path.join(args.checkpoint, 'log.txt'))
        #logger.set_names(['Epoch', 'Learning Rate', 'Train Loss'])
        logger.set_names(['Epoch', 'Learning Rate','Train Loss', 'Recall','Precision','F1'])
    
    bestResult = 0
    for epoch in range(start_epoch, args.n_epoch):
        #adjust_learning_rate(args, optimizer, epoch)
        #scheduler.step()
        print('\nEpoch: [%d | %d] LR: %f'%(epoch+1, args.n_epoch, optimizer.param_groups[0]['lr']))
        train_loss, scores = train(train_loader, model, optimizer, epoch)
        
        save_checkpoint({
            'epoch':epoch+1,
            'state_dict': model.state_dict(),
            'lr': args.lr, 
            'optimizer': optimizer.state_dict(),
            }, epoch+1, checkpoint=args.checkpoint)
        if args.need_validate and (epoch+1)%5==0:
            print('Validating the model')
            scores = validate(model, args)
            print(scores)
            if  scores['f1_score'] > bestResult:
                print('Save the best model!')
                bestResult = scores['f1_score']
                save_best_checkpoint({
                    'epoch':epoch+1,
                    'state_dict': model.state_dict(),
                    'lr': args.lr,
                    'optimizer': optimizer.state_dict(),
                    }, checkpoint=args.checkpoint)

        logger.append([epoch+1, optimizer.param_groups[0]['lr'], train_loss, scores['recall'],scores['precision'],scores['f1_score']])
    logger.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--arch',type=str, nargs='?', default='unet')
    parser.add_argument('--expansion', type=int, default=5, help='expand the input data size')
    parser.add_argument('--n_epoch', type=int, nargs='?', default=100)
    parser.add_argument('--schedule',type=int, nargs='+', default=[60,90])
    parser.add_argument('--batch_size', type=int, nargs='?', default=200)
    parser.add_argument('--lr', type=float, nargs='?', default=1e-3)
    parser.add_argument('--checkpoint', type=str, default='', metavar='PATH', help='path to save checkpoint')
    parser.add_argument('--pretrain', type=str, default=None, help="Path to previous saved model to restart")
    parser.add_argument('--resume', type=str, default=None, help='Path to previous saved model to restart from')
    parser.add_argument('--need_validate', type=bool, default=True, help='whether to validate the model after some epochs')
    args = parser.parse_args()
    main(args)